import { Routes } from '@angular/router';

import { NovoPedidoComponent}