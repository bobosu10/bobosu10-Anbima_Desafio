import { Component } from '@angular/core';

@Component({
  selector: 'app-novo-pedido',
  imports: [],
  templateUrl: './novo-pedido.html',
  styleUrl: './novo-pedido.css'
})
export class NovoPedido {

}
