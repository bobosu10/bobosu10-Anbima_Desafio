import { Component } from '@angular/core';

@Component({
  selector: 'app-pedidos-lista',
  imports: [],
  templateUrl: './pedidos-lista.html',
  styleUrl: './pedidos-lista.css'
})
export class PedidosLista {

}
